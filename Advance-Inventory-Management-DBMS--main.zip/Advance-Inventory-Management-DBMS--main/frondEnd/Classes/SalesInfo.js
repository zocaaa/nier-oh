
class SaleInfo {
    constructor(prodname,price,amount,total,saledate){
        this.ProductName = prodname;
        this.Price = price;
        this.Amount = amount
        this.Total = total
        this.SaleDate = saledate
    }
}