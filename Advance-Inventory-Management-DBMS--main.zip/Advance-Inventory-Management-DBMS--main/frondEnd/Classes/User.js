class User{
    constructor(username,role){
        this.Username = username;
        this.RoleID = role;
        this.status = "";
    }
}
